
package Compression ;

public class MainClass {

	public static void main(String[] args) {


           Start obj = new Start();
           obj.setVisible(true);

	}


}